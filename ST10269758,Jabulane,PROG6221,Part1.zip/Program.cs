﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp;





class Program
{
    static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        while (true) 
        {
            Console.WriteLine("Welcome To The Recipe App");
            Console.WriteLine("Choose an Option");
            Console.WriteLine("1.Add a Recipe");
            Console.WriteLine("2.View all Recipes");
            Console.WriteLine("3.Exit");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    AddRecipe();
                    break;
                case 2:
                    ViewRecipes();
                    break;
                
                default:
                    Console.WriteLine("invalid Choic Try Again!");
                    break;
            }

        }
    }

    static void AddRecipe()
    {
        //Promts user to enter the name of their respective recipe
        Console.WriteLine("Enter the name of the Recipe");
        string name = Console.ReadLine();
        // the user must enter the number of ingrediants 
        Console.WriteLine("Enter number of ingrediants (separated by commas):");
        string[] ingrediants = Console.ReadLine().Split(',');
        //user must follow instructions
        Console.WriteLine("instruction interms of name, qunatity and measurement(separated by comma):");
        string[] instructions = Console.ReadLine().Split(',');
        //description for the recipe
        Console.WriteLine("Enter description for the recipe");
        string description = Console.ReadLine();

        Recipe newRecipe = new Recipe(name,ingrediants, instructions,description);

        Console.WriteLine("Recipe added succesfully");
    }

    static void ViewRecipes()
    {
        Console.WriteLine("All Recipes:");
        foreach (Recipe recipe in recipes)
        {
            Console.WriteLine(recipe.GetSummary());
        }

    }
}

public class Recipe
{
    public string Name { get; }
    public List<string> Ingrediants { get; }
    public List<string> Instructions { get; }
    public string Description { get; }

    public Recipe(string name, string[] ingridiants, string[] instruction, string description)
    {
        this.Name = name;
        this.Ingrediants = new List<string>(ingridiants);
        this.Instructions = new List<string>(instruction);
        this.Description = description;

    }
    public string GetSummary()
    {

        string ingrediantsList = string.Join(",", Ingrediants);
        string instructionsList = string.Join(",", Instructions);

        return "$Name: { this.Name} \r\nIngrediants: { this.IngrediantsList} \r\nInstruction: { this.InstructionsList} \r\nDescription: { this.Description}";
    }


}



